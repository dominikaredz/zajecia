﻿using System;
using System.IO;
using System.Text;
using System.Xml.Serialization;

class User{
    protected string name { get; set; }
    protected string email { get; set; }

    protected List<Task> tasks;

    public string Name => name;
    public string Email => email;
    public List<Task> Tasks => tasks;
    public User(string name, string email){
        this.name = name;
        this.email = email;
        tasks = new List<Task>();
    }

    public void AddTask(Task task){
        if (!tasks.Contains(task))
            tasks.Add(task);
    }

    public void UserTask()
    {
        Console.WriteLine($"Zadania użytkownika {name}:");
        if (tasks == null || tasks.Count == 0)
        {
            Console.WriteLine("Użytkownik nie ma zadań do zrealizowania.");
            return;
        }
        int i = 1;
        foreach (var task in tasks){
            Console.WriteLine($"{i}.");
            Console.WriteLine(task.ToString());
            i++;
        }
    }

    public override string ToString() => $"{name}, {email}";
}

class Task{

    protected int taskAmount;

    //DODAC METODE WYKORZYSTUJĄCĄ ILOŚĆ ZADAŃ W TWORZENIU NAZWY NOWEGO ZADANIA

    protected string title; 

    protected string opis;

    protected DateTime dateTime;

    //JAK ZAPROGRAMOWAĆ USTAWIENIE DATY?

    protected User user;

    public string Title => title;

    public enum Status{
        do_zrobienia,
        w_trakcie_realizacji,
        skonczone,
    }

    public Status status;
    
    public Task() : this(null, DateTime.MinValue, "Zadanie", "Brak opisu"){}
    public Task(DateTime dateTime, string title, string opis) : this(null, dateTime, title, opis){}
    public Task(User user, DateTime dateTime) : this(user, dateTime, "Zadanie", "Brak opisu"){}

    public Task(User user, DateTime dateTime, string title, string opis){
        this.user = user;
        this.dateTime = dateTime;
        this.title = title;
        this.opis = opis;
        status = Status.do_zrobienia; 
    }

    public void AssignUser(User user){
        this.user = user;
        user.AddTask(this); 
    }
    public override string ToString() => $"Właściciel zadania: {user}\nTytuł: {title}\nOpis zadania: {opis}\nData realizacji: {dateTime}\nStatus: {status}";
}


class Project{

    protected string name;

    public string Name => name;

    protected List<Task> tasks;
    public List<Task> Tasks => tasks;

    public Project() : this("Brak nazwy"){}

    public Project(string name){
        this.name = name;
        tasks = new List<Task>();
    }

    public void AddTask(Task task){
    if (!tasks.Contains(task))
        tasks.Add(task);
    }

    public void ProjectTask()
    {
        Console.WriteLine($"Zadania w projekcie {name}:");
        if (tasks == null || tasks.Count == 0)
        {
            Console.WriteLine("Brak zadań do zrealizowania.");
            return;
        }
        int i = 1;
        foreach (var task in tasks){
            Console.WriteLine($"{i}.");
            Console.WriteLine(task.ToString());
            i++;
        }
    }

    public void SortTask(){
        List<Task> toDo = new List<Task>();
        List<Task> inProgress = new List<Task>();
        List<Task> done = new List<Task>();
        foreach(var task in tasks){
            if (task.status == Task.Status.do_zrobienia){
                toDo.Add(task);
            }
            if (task.status == Task.Status.w_trakcie_realizacji){
                inProgress.Add(task);
            }
            if (task.status == Task.Status.skonczone){
                done.Add(task);
            }                       
        }     
    }

    //DO POPRAWY
    public void PassedDeadline(){
        List<Task> PassedDeadline = new List<Task>();
        foreach(var task in tasks){
            if (task.status == Task.Status.do_zrobienia){
                PassedDeadline.Add(task);
            }
        }
    }

    public override string ToString() => $"Nazwa projektu: '{name}', zadania:\n {string.Join(", ", tasks)}\n";

}

class ToDoManager{
    protected Dictionary<string, User> users;
    
    protected List<Project> projects;

    public ToDoManager() : this(new Dictionary<string, User>(), new List<Project>()){}

    public ToDoManager(Dictionary <string, User> users, List<Project> projects){
        this.users = users;
        this.projects = projects;
    }

    public bool IfNull(string inp){
        if (inp == "" || inp == null){
            Console.WriteLine($"Nie wprowadzono żadnych danych.");
            return true;
        }
        return false;
    }
    public void AddUser(string str){
        Console.WriteLine("Podaj imię użytkownika: ");
        var name = Console.ReadLine().Trim().ToUpper();
        
        if(IfNull(name)){return;}
        
        if(str == "domyslny"){
            Console.WriteLine("Podaj jego adres email: ");
            var email = Console.ReadLine().Trim().ToUpper();
            if(IfNull(email)){return;}
            User user = new User(name,email);
            users.Add($"{email}", user);
            }
        else{
            User user = new User(name,str);
            users.Add($"{str}", user);
        }
    }

    public void AddProject(string title){
        if(title == "domyslny"){
            Console.WriteLine("Podaj nazwę projektu: ");
            var name = Console.ReadLine().Trim();
            if(IfNull(name)){return;}
            Project project = new Project(name);
            projects.Add(project);
            //Console.WriteLine(this.ToString());
        }
        else{
            Project project = new Project(title);
            projects.Add(project);
        }

    }
    public void AddTaskToProject(){

        Console.WriteLine("Podaj tytuł zadania: ");
        var title = Console.ReadLine().Trim();
        if(IfNull(title)){return;}

        Console.WriteLine("Podaj opis zadania: ");
        var opis = Console.ReadLine().Trim();
        if(IfNull(opis)){return;}

        Console.WriteLine("Podaj datę realizacji: ");
        string input = Console.ReadLine().Trim().ToUpper();
        if(IfNull(input)){return;}

        DateTime dateTime;
        Task task;
        if(DateTime.TryParse(input, out dateTime) && (dateTime > DateTime.Now)){
            Console.WriteLine("Poprawne dane");
        }
        else{
            Console.WriteLine("Niepoprawne dane. Spróbuj ponownie.");
            return;
        }

        Console.WriteLine("Podaj nazwę projektu, do którego chcesz dodać zadanie: ");
        var pr = Console.ReadLine().Trim().ToUpper();
        if(IfNull(pr)){return;}
        var project = projects.FirstOrDefault(p => p.Name.Equals(pr, StringComparison.OrdinalIgnoreCase));
        if(project == null){
            Console.WriteLine("Projekt nie istnieje.");
            Console.WriteLine("Czy chciałbyś utworzyć taki projekt? t/n");
            string input2 = Console.ReadLine().Trim().ToUpper();
            if(input2 == "T"){AddProject(pr);}
            project = projects.FirstOrDefault(p => p.Name.Equals(pr, StringComparison.OrdinalIgnoreCase));
            task = new Task(dateTime, title, opis);
            project.AddTask(task);
            return;
        }
        else{        
        task = new Task(dateTime, title, opis);
        project.AddTask(task);
        }

        Console.WriteLine("Czy chcesz przypisać te zadanie do konkretnego użytkownika? T/N");
        var choice = Console.ReadLine().Trim().ToUpper();
        if (choice == "T"){
            Console.WriteLine("Podaj e-maila użytkownika, dla którego chcesz przypisać zadanie: ");
            string userEmail = Console.ReadLine();
            if(IfNull(userEmail)){return;}
            if (users.ContainsKey(userEmail))
            {
                var user = users[userEmail];
                task.AssignUser(user);
            }
            else{
                Console.WriteLine("Nie znaleziono użytkownika o podanym adresie e-mail.");
                Console.WriteLine("Czy chciałbyś utworzyć takiego użytkownika? T/N");
                var choice2 = Console.ReadLine().Trim().ToUpper();
                if (choice == "T"){
                    AddUser(userEmail);
                }
                
            }}
        else {return;}


    }

    public void AssignUser(){
        Console.WriteLine("Podaj nazwę zadania, do którego chcesz przypisać użytkownika: ");
        var taskTitle = Console.ReadLine().Trim().ToUpper();
        Task foundTask = null;
        foreach (var project in projects){
            foreach (var task in project.Tasks){
                if (task.Title.Equals(taskTitle, StringComparison.OrdinalIgnoreCase)){
                    foundTask = task;
                    //Console.WriteLine($"znaleziono: {foundTask}");
                    break;
                }
            }
        }
        if (foundTask == null){
            Console.WriteLine("Nie znaleziono zadania o danej nazwie. Czy chciałbyś je utworzyć? T/N");
            var choice = Console.ReadLine().Trim().ToUpper();
            if (choice == "T"){
                AddTaskToProject();
                return;
            }
            else{
                return;
            }
        }

        Console.WriteLine("Podaj e-maila użytkownika, dla którego chcesz przypisać zadanie: ");
        string userEmail = Console.ReadLine();
        if(IfNull(userEmail)){return;}
        if (users.ContainsKey(userEmail))
        {
            var user = users[userEmail];
            foundTask.AssignUser(user);
        }
        else{
            Console.WriteLine("Nie znaleziono użytkownika o podanym adresie e-mail.");
            return;
        }

    }
    
    

    public void ChangeStatus(){
        Console.WriteLine("Podaj nazwę zadania, do którego chcesz zmienić status realizacji: ");
        var taskTitle = Console.ReadLine().Trim().ToUpper();
        Task foundTask = null;
        foreach (var project in projects){
            foreach (var task in project.Tasks){
                if (task.Title.Equals(taskTitle, StringComparison.OrdinalIgnoreCase)){
                    foundTask = task;
                    //Console.WriteLine($"znaleziono: {foundTask}");
                    break;
                }
            }
        }
        if (foundTask == null){
            Console.WriteLine("Nie znaleziono zadania o danej nazwie. Czy chciałbyś je utworzyć? T/N");
            var choice = Console.ReadLine().Trim().ToUpper();
            if (choice == "T"){
                AddTaskToProject();
            }
            else{
                return;
            }
        }
        Console.WriteLine("Wybierz nowy status realizacji zadania: 1. Do zrobienia\n2.W trakcie realizacji\n3.Skończone.\nWybierz odpowiedni numer: ");
        var input = Console.ReadLine();
        int choice2;
        if(int.TryParse(input, out choice2)){
            Console.WriteLine("Poprawne dane");
        }
        else{
            Console.WriteLine("To nie jest liczba.");
            return;
        }

        if (choice2 == 1){foundTask.status = Task.Status.do_zrobienia;}
        else if (choice2 == 2){foundTask.status = Task.Status.w_trakcie_realizacji;}
        else if (choice2 == 3){foundTask.status = Task.Status.skonczone;}
        else{Console.WriteLine("Niepoprawna liczba.");}

        Console.WriteLine($"Nowe dane: {foundTask}");

    }

    public void AllProjects(){

        if(projects.Count == 0){
            Console.WriteLine("Lista projektów jest pusta, chciałbyś dodać nowy projekt? T/N");
            string input = Console.ReadLine().Trim().ToUpper();
            if(input == "T"){string df = "domyslny"; AddProject(df);}
        }

        if(projects.Count > 0){
            Console.WriteLine("Lista wszystkich projektów: ");
            foreach(Project pro in projects){
                Console.WriteLine(pro.ToString());
            }
        }
    }

    public void AllUsers(){
        Console.WriteLine("Lista wszystkich użtykowników: ");

        if(users.Count == 0){
            Console.WriteLine("Lista użytkowników jest pusta, chciałbyś dodać nowego użytkownika? T/N");
            string input = Console.ReadLine().Trim().ToUpper();
                if(input == "T"){string df = "domyslny"; AddUser(df);}
        }

        if(users.Count > 0){
            foreach(User us in users.Values){

                us.UserTask();

            }
        }
    }

}


class Program(){
    static void Main(string[] args){

        ToDoManager toDoManager = new ToDoManager();

        int choice;

        do{
            Console.WriteLine($"Witaj w programie do obsługi zadań ToDoManager. Wybierz, co chcesz zrobić:\n1.Dodaj użytkownika.\n2.Dodaj nowy projekt.\n3.Dodaj nowe zadanie.\n4.Przypisz użytkownika do zadania.\n5.Zmień status realizacji zadania.\n6.Wyświetl wszystkie projekty.\n7.Wyświetl wszystkich użytkowników i nalezące do nich zadania.\n8.Wyjdź z programu.");
            var input = Console.ReadLine();
            if(int.TryParse(input, out choice)){
                if(choice == 1){string df2 = "domyslny"; toDoManager.AddUser(df2);}
                if(choice == 2){string df = "domyslny"; toDoManager.AddProject(df);}
                if(choice == 3){toDoManager.AddTaskToProject();}
                if(choice == 4){toDoManager.AssignUser();}
                if(choice == 5){toDoManager.ChangeStatus();}
                if(choice == 6){toDoManager.AllProjects();}
                if(choice == 7){toDoManager.AllUsers();}
            }
            else{
                Console.WriteLine("To nie jest liczba.");
            }
        
        }
        while (choice != 8);

    }
}
